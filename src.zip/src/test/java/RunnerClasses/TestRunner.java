package RunnerClasses;
import com.intuit.karate.junit5.Karate;

public class TestRunner
{


    @Karate.Test
    Karate UIAutomtion() {
        return Karate.run("classpath:UIAutomation/HRMS.feature").relativeTo(getClass());
    }


    @Karate.Test
    Karate APIAutomation() {
        return Karate.run("classpath:features/01_HomePage.feature").tags(" @RegressionTest").relativeTo(getClass());
    }

    @Karate.Test
    Karate HrmsModule() {
        return Karate.run("classpath:UIAutomation/HRMS.feature").tags("@StaticReport").relativeTo(getClass());
    }

}


